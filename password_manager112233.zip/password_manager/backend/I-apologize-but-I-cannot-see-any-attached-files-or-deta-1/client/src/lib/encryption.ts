import CryptoJS from "crypto-js";

export function encryptPassword(password: string, masterKey: string): string {
  return CryptoJS.AES.encrypt(password, masterKey).toString();
}

export function decryptPassword(encrypted: string, masterKey: string): string {
  const bytes = CryptoJS.AES.decrypt(encrypted, masterKey);
  return bytes.toString(CryptoJS.enc.Utf8);
}

export function generatePassword(length = 16): string {
  const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+";
  let password = "";
  for (let i = 0; i < length; i++) {
    password += charset.charAt(Math.floor(Math.random() * charset.length));
  }
  return password;
}

export function checkPasswordStrength(password: string): {
  score: number;
  feedback: string;
} {
  let score = 0;
  
  if (password.length >= 12) score += 2;
  else if (password.length >= 8) score += 1;
  
  if (/[A-Z]/.test(password)) score += 1;
  if (/[a-z]/.test(password)) score += 1;
  if (/[0-9]/.test(password)) score += 1;
  if (/[^A-Za-z0-9]/.test(password)) score += 1;
  
  const feedback = [
    "Very weak",
    "Weak",
    "Moderate",
    "Strong",
    "Very strong",
  ][Math.min(score, 4)];
  
  return { score, feedback };
}
