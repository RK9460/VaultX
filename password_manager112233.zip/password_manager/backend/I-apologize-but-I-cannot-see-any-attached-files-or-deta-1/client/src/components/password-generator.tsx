import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Clipboard, RefreshCw } from "lucide-react";
import { generatePassword } from "@/lib/encryption";
import { useToast } from "@/hooks/use-toast";
import PasswordStrength from "./password-strength";

export default function PasswordGenerator() {
  const { toast } = useToast();
  const [length, setLength] = useState(16);
  const [password, setPassword] = useState(() => generatePassword(length));
  const [options, setOptions] = useState({
    uppercase: true,
    lowercase: true,
    numbers: true,
    symbols: true,
  });

  function generate() {
    setPassword(generatePassword(length));
  }

  function copyToClipboard() {
    navigator.clipboard.writeText(password);
    toast({
      title: "Copied to clipboard",
      description: "Password has been copied to your clipboard",
    });
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Password Generator</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex gap-2">
          <Input 
            value={password} 
            readOnly 
            className="font-mono"
          />
          <Button 
            variant="outline" 
            size="icon"
            onClick={copyToClipboard}
          >
            <Clipboard className="h-4 w-4" />
          </Button>
          <Button 
            variant="outline" 
            size="icon"
            onClick={generate}
          >
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>

        <PasswordStrength password={password} />

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Label>Password Length: {length}</Label>
            <Slider
              value={[length]}
              onValueChange={([value]) => setLength(value)}
              min={8}
              max={32}
              step={1}
              className="w-[200px]"
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="uppercase">Include Uppercase</Label>
              <Switch
                id="uppercase"
                checked={options.uppercase}
                onCheckedChange={(checked) =>
                  setOptions((prev) => ({ ...prev, uppercase: checked }))
                }
              />
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="lowercase">Include Lowercase</Label>
              <Switch
                id="lowercase"
                checked={options.lowercase}
                onCheckedChange={(checked) =>
                  setOptions((prev) => ({ ...prev, lowercase: checked }))
                }
              />
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="numbers">Include Numbers</Label>
              <Switch
                id="numbers"
                checked={options.numbers}
                onCheckedChange={(checked) =>
                  setOptions((prev) => ({ ...prev, numbers: checked }))
                }
              />
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="symbols">Include Symbols</Label>
              <Switch
                id="symbols"
                checked={options.symbols}
                onCheckedChange={(checked) =>
                  setOptions((prev) => ({ ...prev, symbols: checked }))
                }
              />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
