import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Search,
  Clipboard,
  Edit,
  Plus,
  Key,
} from "lucide-react";
import { decryptPassword } from "@/lib/encryption";
import type { Password } from "@shared/schema";

export default function PasswordList() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [search, setSearch] = useState("");

  const { data: passwords = [], isLoading } = useQuery<Password[]>({
    queryKey: ["/api/passwords"],
    select: (data) => data.sort((a, b) => 
      a.title.toLowerCase().localeCompare(b.title.toLowerCase())
    ),
  });

  const filteredPasswords = passwords.filter((p) =>
    p.title.toLowerCase().includes(search.toLowerCase()) ||
    p.username.toLowerCase().includes(search.toLowerCase()) ||
    p.category?.toLowerCase().includes(search.toLowerCase())
  );

  async function copyPassword(password: Password) {
    const decrypted = decryptPassword(password.password, user!.masterKey);
    await navigator.clipboard.writeText(decrypted);
    toast({
      title: "Password copied",
      description: "Password has been copied to your clipboard",
    });
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search passwords..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Button onClick={() => window.location.href = '/add-password'}>
          <Plus className="mr-2 h-4 w-4" />
          Add Password
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filteredPasswords.map((password) => (
          <Card key={password.id} className="relative">
            <CardHeader className="pb-2">
              <div className="flex items-start justify-between">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Key className="h-4 w-4" />
                  {password.title}
                </CardTitle>
                <div className="flex gap-2 mt-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => copyPassword(password)}
                  >
                    <Clipboard className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => window.location.href = `/edit-password/${password.id}`}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                {password.username}
              </p>
              {password.category && (
                <div className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold">
                  {password.category}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}