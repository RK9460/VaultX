import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { insertPasswordSchema, type InsertPassword } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { encryptPassword, decryptPassword } from "@/lib/encryption";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Loader2 } from "lucide-react";
import PasswordStrength from "./password-strength";

export default function PasswordForm({ 
  passwordId, 
  onSave 
}: { 
  passwordId: number | null;
  onSave: () => void;
}) {
  const { user } = useAuth();
  const { toast } = useToast();

  const form = useForm<InsertPassword>({
    resolver: zodResolver(insertPasswordSchema),
    defaultValues: {
      title: "",
      username: "",
      password: "",
      url: "",
      notes: "",
      category: "",
    },
  });

  // Fetch existing password if editing
  const { data: existingPassword, isLoading: isLoadingPassword } = useQuery({
    queryKey: ["/api/passwords", passwordId],
    enabled: !!passwordId,
    queryFn: async () => {
      const res = await fetch(`/api/passwords/${passwordId}`);
      const data = await res.json();
      return {
        ...data,
        password: decryptPassword(data.password, user!.masterKey),
      };
    },
  });

  // Update form when editing existing password
  useEffect(() => {
    if (existingPassword) {
      form.reset(existingPassword);
    }
  }, [existingPassword, form]);

  const createMutation = useMutation({
    mutationFn: async (data: InsertPassword) => {
      const encryptedData = {
        ...data,
        password: encryptPassword(data.password, user!.masterKey),
      };
      const res = await apiRequest("POST", "/api/passwords", encryptedData);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/passwords"] });
      toast({ title: "Password saved successfully" });
      form.reset();
      onSave();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to save password",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (data: InsertPassword) => {
      const encryptedData = {
        ...data,
        password: encryptPassword(data.password, user!.masterKey),
      };
      const res = await apiRequest("PATCH", `/api/passwords/${passwordId}`, encryptedData);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/passwords"] });
      toast({ title: "Password updated successfully" });
      onSave();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update password",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  function onSubmit(data: InsertPassword) {
    if (passwordId) {
      updateMutation.mutate(data);
    } else {
      createMutation.mutate(data);
    }
  }

  if (passwordId && isLoadingPassword) {
    return (
      <div className="flex justify-center p-4">
        <Loader2 className="h-6 w-6 animate-spin" />
      </div>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{passwordId ? "Edit Password" : "Add New Password"}</CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g. Gmail Account" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="username"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Username</FormLabel>
                  <FormControl>
                    <Input placeholder="Username or email" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Password</FormLabel>
                  <FormControl>
                    <Input type="password" {...field} />
                  </FormControl>
                  <PasswordStrength password={field.value} />
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="url"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Website URL</FormLabel>
                  <FormControl>
                    <Input placeholder="https://" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g. Work, Personal" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Additional notes..." {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex justify-end gap-2">
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => {
                  form.reset();
                  onSave();
                }}
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                disabled={createMutation.isPending || updateMutation.isPending}
              >
                {createMutation.isPending || updateMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                ) : null}
                {passwordId ? "Update" : "Save"} Password
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
