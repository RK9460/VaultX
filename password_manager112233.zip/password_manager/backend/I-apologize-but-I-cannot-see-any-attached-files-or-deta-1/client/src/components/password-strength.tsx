import { Progress } from "@/components/ui/progress";
import { checkPasswordStrength } from "@/lib/encryption";

export default function PasswordStrength({ password }: { password: string }) {
  const { score, feedback } = checkPasswordStrength(password);
  const progress = (score / 4) * 100;
  
  const colorClass = {
    0: "text-destructive",
    1: "text-destructive",
    2: "text-yellow-500",
    3: "text-green-500",
    4: "text-green-600",
  }[score];

  return (
    <div className="space-y-2">
      <Progress value={progress} className="h-2" />
      <p className={`text-sm ${colorClass}`}>{feedback}</p>
    </div>
  );
}
