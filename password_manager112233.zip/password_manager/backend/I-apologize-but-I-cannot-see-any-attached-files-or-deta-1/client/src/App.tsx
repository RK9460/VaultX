import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "./hooks/use-auth";
import { Shield } from "lucide-react";
import { Tabs, TabsList, TabsContent, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import PasswordList from "@/components/password-list";
import PasswordGenerator from "@/components/password-generator";
import AuthPage from "@/pages/auth-page";
import PasswordPage from "@/pages/password-page";

function Header() {
  const { logoutMutation } = useAuth();
  return (
    <div className="flex items-center justify-between p-4">
      <div className="flex items-center gap-2">
        <Shield className="h-6 w-6" />
        <h1 className="text-xl font-bold">SecureVault</h1>
      </div>
      <Button variant="outline" onClick={() => logoutMutation.mutate()}>
        Logout
      </Button>
    </div>
  );
}

function MainContent() {
  return (
    <div className="container mx-auto p-4">
      <Header />
      <Separator className="my-4" />
      <Switch>
        <Route path="/add-password">
          <PasswordPage />
        </Route>
        <Route path="/edit-password/:id">
          <PasswordPage />
        </Route>
        <Route>
          <Tabs defaultValue="passwords" className="w-full">
            <TabsList className="mb-4">
              <TabsTrigger value="passwords">Passwords</TabsTrigger>
              <TabsTrigger value="generator">Generator</TabsTrigger>
            </TabsList>
            <TabsContent value="passwords">
              <PasswordList />
            </TabsContent>
            <TabsContent value="generator">
              <PasswordGenerator />
            </TabsContent>
          </Tabs>
        </Route>
      </Switch>
    </div>
  );
}

function Router() {
  const { user } = useAuth();
  return user ? <MainContent /> : <AuthPage />;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;