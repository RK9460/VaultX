import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import {
  ResizableHandle,
  ResizablePanel,
  ResizablePanelGroup,
} from "@/components/ui/resizable";
import { Button } from "@/components/ui/button";
import { LogOut } from "lucide-react";
import PasswordList from "@/components/password-list";
import PasswordForm from "@/components/password-form";
import PasswordGenerator from "@/components/password-generator";

export default function HomePage() {
  const { user, logoutMutation } = useAuth();
  const [selectedPasswordId, setSelectedPasswordId] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold">SecureVault</h1>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">
              {user?.username}
            </span>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => logoutMutation.mutate()}
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="container mx-auto px-4 py-6">
        <ResizablePanelGroup direction="horizontal">
          {/* Password list */}
          <ResizablePanel defaultSize={30}>
            <PasswordList
              selectedId={selectedPasswordId}
              onSelect={setSelectedPasswordId}
            />
          </ResizablePanel>
          
          <ResizableHandle />
          
          {/* Password form and generator */}
          <ResizablePanel defaultSize={70}>
            <div className="space-y-6">
              <PasswordForm
                passwordId={selectedPasswordId}
                onSave={() => setSelectedPasswordId(null)}
              />
              <PasswordGenerator />
            </div>
          </ResizablePanel>
        </ResizablePanelGroup>
      </main>
    </div>
  );
}
