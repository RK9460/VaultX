import { useState } from "react";
import { useLocation } from "wouter";
import PasswordForm from "@/components/password-form";

export default function PasswordPage() {
  const [, setLocation] = useLocation();
  const passwordId = window.location.pathname.startsWith('/edit-password') 
    ? parseInt(window.location.pathname.split('/').pop()!) 
    : null;

  return (
    <div className="container mx-auto p-4 max-w-2xl">
      <PasswordForm 
        passwordId={passwordId} 
        onSave={() => setLocation('/')} 
      />
    </div>
  );
}
