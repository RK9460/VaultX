import string
import random
import re
from datetime import datetime, timedelta

def generate_password(length=16, use_uppercase=True, use_lowercase=True,
                     use_numbers=True, use_symbols=True):
    """Generate a secure random password with specified criteria."""

    characters = ''
    if use_uppercase:
        characters += string.ascii_uppercase
    if use_lowercase:
        characters += string.ascii_lowercase
    if use_numbers:
        characters += string.digits
    if use_symbols:
        characters += string.punctuation

    if not characters:
        characters = string.ascii_letters + string.digits

    # Ensure at least one character from each selected type
    password = []
    if use_uppercase:
        password.append(random.choice(string.ascii_uppercase))
    if use_lowercase:
        password.append(random.choice(string.ascii_lowercase))
    if use_numbers:
        password.append(random.choice(string.digits))
    if use_symbols:
        password.append(random.choice(string.punctuation))

    # Fill the rest randomly
    remaining_length = length - len(password)
    password.extend(random.choice(characters) for _ in range(remaining_length))

    # Shuffle the password
    random.shuffle(password)

    return ''.join(password)

def check_password_strength(password):
    """Check password strength and return a score and feedback."""
    score = 0
    feedback = []

    # Length check
    if len(password) >= 12:
        score += 2
        feedback.append("Good length")
    elif len(password) >= 8:
        score += 1
        feedback.append("Minimum length met")
    else:
        feedback.append("Password is too short")

    # Character type checks
    if re.search(r'[A-Z]', password):
        score += 1
        feedback.append("Contains uppercase")
    else:
        feedback.append("Add uppercase letters")

    if re.search(r'[a-z]', password):
        score += 1
        feedback.append("Contains lowercase")
    else:
        feedback.append("Add lowercase letters")

    if re.search(r'\d', password):
        score += 1
        feedback.append("Contains numbers")
    else:
        feedback.append("Add numbers")

    if re.search(r'[^A-Za-z0-9]', password):
        score += 1
        feedback.append("Contains symbols")
    else:
        feedback.append("Add symbols")

    # Additional checks
    if len(set(password)) < len(password) * 0.75:
        score -= 1
        feedback.append("Too many repeated characters")

    # Sequential character check
    if re.search(r'(abc|bcd|cde|def|efg|fgh|ghi|hij|ijk|jkl|klm|lmn|mno|nop|opq|pqr|qrs|rst|stu|tuv|uvw|vwx|wxy|xyz|012|123|234|345|456|567|678|789)', password.lower()):
        score -= 1
        feedback.append("Contains sequential characters")

    # Common word check
    common_words = ['password', 'admin', 'user', 'login', '123456', 'qwerty']
    if any(word in password.lower() for word in common_words):
        score -= 2
        feedback.append("Contains common password patterns")

    # Calculate final score (ensure it's between 0 and 5)
    final_score = max(0, min(5, score))

    # Get the appropriate strength label
    strength_labels = {
        0: "Very Weak",
        1: "Weak",
        2: "Fair",
        3: "Good",
        4: "Strong",
        5: "Very Strong"
    }

    return {
        'score': final_score,
        'feedback': ", ".join(feedback),
        'strength': strength_labels[final_score],
        'suggestions': [f for f in feedback if "Add" in f or "Too" in f or "Contains common" in f]
    }

def estimate_crack_time(password):
    """Estimate the time it would take to crack a password."""
    # Calculate entropy and estimate crack time
    char_sets = {
        'lowercase': len(set(c for c in password if c.islower())),
        'uppercase': len(set(c for c in password if c.isupper())),
        'digits': len(set(c for c in password if c.isdigit())),
        'symbols': len(set(c for c in password if not c.isalnum()))
    }

    total_chars = sum(char_sets.values())
    if total_chars == 0:
        return "Instant"

    entropy = len(password) * (total_chars / 4) * 2

    # Rough estimates of time to crack based on entropy
    if entropy < 28:
        return "Instant"
    elif entropy < 36:
        return "Hours"
    elif entropy < 60:
        return "Days"
    elif entropy < 128:
        return "Years"
    else:
        return "Centuries"

def is_password_expired(expiration_date):
    """Check if a password has expired."""
    if not expiration_date:
        return False
    return datetime.utcnow() > expiration_date

def should_change_password(last_changed_date, max_age_days=90):
    """Check if a password should be changed based on age."""
    if not last_changed_date:
        return True
    max_age = timedelta(days=max_age_days)
    return datetime.utcnow() - last_changed_date > max_age