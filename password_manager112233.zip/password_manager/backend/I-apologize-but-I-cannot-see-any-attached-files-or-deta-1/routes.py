from app import app, db, User, Password, AuditLog, cipher_suite, SharedPassword, LoginAttempt, SecurityQuestion, PasswordResetToken
from flask import request, jsonify, session
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
from utils import check_password_strength, generate_password, is_password_expired
import secrets
import re
import json

def validate_email(email):
    """Validate email format using regex"""
    email_pattern = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
    return bool(email_pattern.match(email))

def validate_phone(phone):
    """Validate phone number (must be exactly 10 digits)"""
    return bool(re.match(r'^\d{10}$', phone))

def log_audit(user_id, action, resource_type, resource_id=None, details=None):
    """Create an audit log entry"""
    log = AuditLog(
        user_id=user_id,
        action=action,
        resource_type=resource_type,
        resource_id=resource_id,
        details=details,
        ip_address=request.remote_addr
    )
    db.session.add(log)
    db.session.commit()

def log_login_attempt(user_id, success):
    """Log login attempt with IP and location information"""
    attempt = LoginAttempt(
        user_id=user_id,
        ip_address=request.remote_addr,
        success=success,
        user_agent=request.headers.get('User-Agent'),
        location=request.headers.get('X-Forwarded-For', request.remote_addr)
    )
    db.session.add(attempt)
    db.session.commit()

@app.before_request
def update_last_active():
    """Update user's last active timestamp"""
    if current_user.is_authenticated:
        current_user.last_active = datetime.utcnow()
        db.session.commit()

# User Management Routes
@app.route('/api/register', methods=['POST'])
def register():
    data = request.get_json()

    # Validate required fields
    required_fields = ['username', 'password', 'email', 'phone']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'{field} is required'}), 400

    # Validate email format
    if not validate_email(data['email']):
        return jsonify({'error': 'Invalid email format'}), 400

    # Validate phone number
    if not validate_phone(data['phone']):
        return jsonify({'error': 'Phone number must be exactly 10 digits'}), 400

    # Check for existing username or email
    if User.query.filter_by(username=data['username']).first():
        return jsonify({'error': 'Username already exists'}), 400

    if User.query.filter_by(email=data['email']).first():
        return jsonify({'error': 'Email already registered'}), 400

    # Check password strength
    strength = check_password_strength(data['password'])
    if strength['score'] < 3:
        return jsonify({'error': 'Password is too weak. ' + strength['feedback']}), 400

    # Generate master key for password encryption
    master_key = secrets.token_hex(16)

    user = User(
        username=data['username'],
        email=data['email'],
        phone=data['phone'],
        password_hash=generate_password_hash(data['password']),
        master_key=master_key,
        created_at=datetime.utcnow(),
        last_login=datetime.utcnow(),
        last_password_change=datetime.utcnow()
    )

    db.session.add(user)
    db.session.commit()

    log_audit(user.id, 'register', 'user', user.id)
    login_user(user)

    return jsonify({
        'id': user.id,
        'username': user.username,
        'email': user.email,
        'phone': user.phone,
        'master_key': user.master_key
    }), 201

@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json()
    user = User.query.filter_by(username=data['username']).first()

    # Log the login attempt
    success = False
    if user:
        if user.is_locked:
            log_login_attempt(user.id, False)
            return jsonify({'error': 'Account is locked. Please contact support.'}), 403

        if check_password_hash(user.password_hash, data['password']):
            user.last_login = datetime.utcnow()
            user.failed_login_attempts = 0
            db.session.commit()

            success = True
            log_login_attempt(user.id, True)
            log_audit(user.id, 'login', 'user', user.id)
            login_user(user)

            # Set session timeout
            session.permanent = True

            return jsonify({
                'id': user.id,
                'username': user.username,
                'email': user.email,
                'phone': user.phone,
                'master_key': user.master_key
            })

    if user:
        user.failed_login_attempts += 1
        if user.failed_login_attempts >= 5:
            user.is_locked = True
        db.session.commit()
        log_login_attempt(user.id, False)

    return jsonify({'error': 'Invalid credentials'}), 401

@app.route('/api/security/reset-password', methods=['POST'])
def reset_password():
    """Reset password using security questions"""
    data = request.get_json()
    user = User.query.filter_by(email=data['email']).first()

    if not user:
        return jsonify({'error': 'User not found'}), 404

    # Verify security questions
    questions = SecurityQuestion.query.filter_by(user_id=user.id).all()
    for q in questions:
        if not check_password_hash(q.answer_hash, data['answers'][str(q.id)]):
            return jsonify({'error': 'Incorrect security answers'}), 401

    # Check new password strength
    strength = check_password_strength(data['new_password'])
    if strength['score'] < 3:
        return jsonify({'error': 'New password is too weak'}), 400

    user.password_hash = generate_password_hash(data['new_password'])
    user.last_password_change = datetime.utcnow()
    user.failed_login_attempts = 0
    user.is_locked = False
    db.session.commit()

    log_audit(user.id, 'reset_password', 'user', user.id)
    return jsonify({'message': 'Password reset successfully'})


@app.route('/api/security/init-recovery', methods=['POST'])
def init_password_recovery():
    """Initialize the password recovery process"""
    data = request.get_json()
    user = User.query.filter_by(email=data['email']).first()

    if not user:
        # Return success even if user not found to prevent email enumeration
        return jsonify({'message': 'If the email exists, recovery instructions have been sent'}), 200

    # Generate a secure reset token
    token = secrets.token_urlsafe(32)
    expires_at = datetime.utcnow() + timedelta(hours=1)

    reset_token = PasswordResetToken(
        user_id=user.id,
        token=token,
        expires_at=expires_at
    )

    db.session.add(reset_token)
    db.session.commit()

    # In a real application, send email here
    log_audit(user.id, 'init_recovery', 'user', user.id)

    return jsonify({
        'message': 'Recovery initiated',
        'token': token,  # In production, this would be sent via email
        'questions': [{'id': q.id, 'question': q.question} for q in user.security_questions]
    })

@app.route('/api/security/verify-answers', methods=['POST'])
def verify_security_answers():
    """Verify security question answers during recovery"""
    data = request.get_json()

    reset_token = PasswordResetToken.query.filter_by(
        token=data['token'],
        used=False
    ).first()

    if not reset_token or reset_token.expires_at < datetime.utcnow():
        return jsonify({'error': 'Invalid or expired token'}), 400

    user = User.query.get(reset_token.user_id)
    if not user:
        return jsonify({'error': 'User not found'}), 404

    # Verify all security questions
    correct_answers = 0
    for answer in data['answers']:
        question = SecurityQuestion.query.get(answer['question_id'])
        if question and check_password_hash(question.answer_hash, answer['answer']):
            correct_answers += 1
            question.last_used = datetime.utcnow()
        else:
            question.failed_attempts += 1

    db.session.commit()

    # Require all answers to be correct
    if correct_answers != len(user.security_questions):
        log_audit(user.id, 'failed_recovery', 'user', user.id, 
                 f"Failed security questions ({correct_answers}/{len(user.security_questions)})")
        return jsonify({'error': 'Incorrect answers'}), 400

    # Mark token as verified but not used
    reset_token.verified = True
    db.session.commit()

    return jsonify({'message': 'Security questions verified successfully'})

@app.route('/api/security/reset-master-password', methods=['POST'])
def reset_master_password():
    """Reset user's master password after verification"""
    data = request.get_json()

    reset_token = PasswordResetToken.query.filter_by(
        token=data['token'],
        verified=True,
        used=False
    ).first()

    if not reset_token or reset_token.expires_at < datetime.utcnow():
        return jsonify({'error': 'Invalid or expired token'}), 400

    user = User.query.get(reset_token.user_id)
    if not user:
        return jsonify({'error': 'User not found'}), 404

    # Validate new password strength
    strength = check_password_strength(data['new_password'])
    if strength['score'] < 3:
        return jsonify({
            'error': 'Password too weak',
            'feedback': strength['feedback']
        }), 400

    # Generate new master key and re-encrypt all passwords
    new_master_key = secrets.token_hex(16)
    passwords = Password.query.filter_by(user_id=user.id).all()

    for password in passwords:
        # Decrypt with old key and re-encrypt with new key
        decrypted = cipher_suite.decrypt(
            password.encrypted_password.encode()
        ).decode()
        password.encrypted_password = cipher_suite.encrypt(
            decrypted.encode()
        ).decode()

    # Update user's password and master key
    user.password_hash = generate_password_hash(data['new_password'])
    user.master_key = new_master_key
    user.last_password_change = datetime.utcnow()
    user.failed_login_attempts = 0
    user.is_locked = False

    # Mark token as used
    reset_token.used = True

    db.session.commit()

    log_audit(user.id, 'reset_master_password', 'user', user.id)

    return jsonify({'message': 'Master password reset successfully'})

@app.route('/api/security/setup', methods=['POST'])
@login_required
def setup_recovery():
    """Set up or update recovery options"""
    data = request.get_json()

    # Update backup email if provided
    if 'backup_email' in data:
        if not validate_email(data['backup_email']):
            return jsonify({'error': 'Invalid backup email format'}), 400
        current_user.backup_email = data['backup_email']

    # Update security questions
    if 'questions' in data:
        if len(data['questions']) < 2:
            return jsonify({'error': 'At least 2 security questions required'}), 400

        # Remove old questions
        SecurityQuestion.query.filter_by(user_id=current_user.id).delete()

        # Add new questions
        for q in data['questions']:
            question = SecurityQuestion(
                user_id=current_user.id,
                question=q['question'],
                answer_hash=generate_password_hash(q['answer'])
            )
            db.session.add(question)

    db.session.commit()
    log_audit(current_user.id, 'setup_recovery', 'user', current_user.id)

    return jsonify({
        'message': 'Recovery options updated successfully',
        'backup_email': current_user.backup_email,
        'questions_count': len(current_user.security_questions)
    })

@app.route('/api/passwords/share', methods=['POST'])
@login_required
def share_password():
    """Share a password with another user"""
    data = request.get_json()
    password = Password.query.get_or_404(data['password_id'])

    if password.user_id != current_user.id:
        return jsonify({'error': 'Unauthorized'}), 403

    shared_with = User.query.filter_by(username=data['username']).first()
    if not shared_with:
        return jsonify({'error': 'User not found'}), 404

    # Check if already shared
    existing_share = SharedPassword.query.filter_by(
        password_id=password.id,
        shared_with_id=shared_with.id
    ).first()

    if existing_share:
        return jsonify({'error': 'Password already shared with this user'}), 400

    shared = SharedPassword(
        password_id=password.id,
        shared_by_id=current_user.id,
        shared_with_id=shared_with.id,
        expires_at=datetime.utcnow() + timedelta(days=data.get('days', 7)),
        can_edit=data.get('can_edit', False)
    )

    password.is_shared = True
    db.session.add(shared)
    db.session.commit()

    log_audit(current_user.id, 'share', 'password', password.id,
              f"Shared with {shared_with.username}")

    return jsonify({'message': 'Password shared successfully'})

@app.route('/api/passwords/shared', methods=['GET'])
@login_required
def get_shared_passwords():
    """Get passwords shared with current user"""
    shared = SharedPassword.query.filter_by(
        shared_with_id=current_user.id,
        expires_at=None
    ).all()

    passwords = []
    for s in shared:
        p = Password.query.get(s.password_id)
        if p:
            passwords.append({
                'id': p.id,
                'title': p.title,
                'username': p.username,
                'password': cipher_suite.decrypt(p.encrypted_password.encode()).decode(),
                'url': p.url,
                'shared_by': User.query.get(s.shared_by_id).username,
                'can_edit': s.can_edit,
                'expires_at': s.expires_at.isoformat() if s.expires_at else None
            })

    return jsonify(passwords)

@app.route('/api/passwords/import', methods=['POST'])
@login_required
def import_passwords():
    """Import passwords from JSON file"""
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400

    try:
        data = json.loads(request.files['file'].read())
        for entry in data:
            password = Password(
                user_id=current_user.id,
                title=entry['title'],
                username=entry['username'],
                encrypted_password=cipher_suite.encrypt(entry['password'].encode()).decode(),
                url=entry.get('url'),
                notes=entry.get('notes'),
                category=entry.get('category'),
                expiration_date=datetime.utcnow() + timedelta(days=90)
            )
            db.session.add(password)

        db.session.commit()
        log_audit(current_user.id, 'import', 'password', details=f"Imported {len(data)} passwords")
        return jsonify({'message': f'Successfully imported {len(data)} passwords'})

    except Exception as e:
        return jsonify({'error': 'Invalid file format'}), 400

@app.route('/api/passwords/export', methods=['GET'])
@login_required
def export_passwords():
    """Export passwords to JSON"""
    passwords = Password.query.filter_by(user_id=current_user.id).all()
    data = [{
        'title': p.title,
        'username': p.username,
        'password': cipher_suite.decrypt(p.encrypted_password.encode()).decode(),
        'url': p.url,
        'notes': p.notes,
        'category': p.category
    } for p in passwords]

    log_audit(current_user.id, 'export', 'password', details=f"Exported {len(data)} passwords")
    return jsonify(data)


@app.route('/api/logout', methods=['POST'])
@login_required
def logout():
    logout_user()
    return jsonify({'message': 'Logged out successfully'})

@app.route('/api/user', methods=['GET'])
@login_required
def get_user():
    return jsonify({
        'id': current_user.id,
        'username': current_user.username,
        'email': current_user.email,
        'phone': current_user.phone,
        'master_key': current_user.master_key
    })

@app.route('/api/passwords', methods=['GET'])
@login_required
def get_passwords():
    passwords = Password.query.filter_by(user_id=current_user.id).all()
    return jsonify([{
        'id': p.id,
        'title': p.title,
        'username': p.username,
        'password': cipher_suite.decrypt(p.encrypted_password.encode()).decode(),
        'url': p.url,
        'notes': p.notes,
        'category': p.category,
        'last_updated': p.last_updated.isoformat(),
        'expiration_date': p.expiration_date.isoformat(),
        'strength_score': p.strength_score
    } for p in passwords])

@app.route('/api/passwords/expired', methods=['GET'])
@login_required
def get_expired_passwords():
    """Get all expired passwords"""
    expired = Password.query.filter(
        Password.user_id == current_user.id,
        Password.expiration_date <= datetime.utcnow()
    ).all()

    return jsonify([{
        'id': p.id,
        'title': p.title,
        'username': p.username,
        'url': p.url,
        'category': p.category,
        'expiration_date': p.expiration_date.isoformat(),
        'days_expired': (datetime.utcnow() - p.expiration_date).days
    } for p in expired])

@app.route('/api/passwords/categories', methods=['GET'])
@login_required
def get_password_categories():
    """Get all unique password categories"""
    categories = db.session.query(Password.category).filter(
        Password.user_id == current_user.id,
        Password.category.isnot(None)
    ).distinct().all()
    return jsonify([c[0] for c in categories if c[0]])


@app.route('/api/passwords', methods=['POST'])
@login_required
def create_password():
    data = request.get_json()

    # Check password strength
    strength = check_password_strength(data['password'])
    encrypted_password = cipher_suite.encrypt(data['password'].encode()).decode()

    # Set expiration date to 90 days from now if not specified
    expiration_date = datetime.utcnow() + timedelta(days=90)
    if 'expiration_days' in data:
        expiration_date = datetime.utcnow() + timedelta(days=int(data['expiration_days']))

    password = Password(
        user_id=current_user.id,
        title=data['title'],
        username=data['username'],
        encrypted_password=encrypted_password,
        url=data.get('url'),
        notes=data.get('notes'),
        category=data.get('category'),
        tags=data.get('tags'),
        expiration_date=expiration_date,
        strength_score=strength['score']
    )

    db.session.add(password)
    db.session.commit()

    log_audit(
        current_user.id,
        'create',
        'password',
        password.id,
        f"Created password for {data['title']}"
    )

    return jsonify({
        'id': password.id,
        'title': password.title,
        'username': password.username,
        'password': data['password'],
        'url': password.url,
        'notes': password.notes,
        'category': password.category,
        'tags': password.tags,
        'expiration_date': password.expiration_date.isoformat(),
        'strength_score': password.strength_score,
        'last_updated': password.last_updated.isoformat()
    }), 201

@app.route('/api/audit-logs', methods=['GET'])
@login_required
def get_audit_logs():
    """Get audit logs for the current user"""
    logs = AuditLog.query.filter_by(user_id=current_user.id)\
        .order_by(AuditLog.timestamp.desc())\
        .limit(100)\
        .all()

    return jsonify([{
        'id': log.id,
        'action': log.action,
        'resource_type': log.resource_type,
        'resource_id': log.resource_id,
        'details': log.details,
        'timestamp': log.timestamp.isoformat(),
        'ip_address': log.ip_address
    } for log in logs])

@app.route('/api/passwords/generate', methods=['POST'])
def generate_secure_password():
    """Generate a secure password based on criteria"""
    data = request.get_json()
    length = data.get('length', 16)
    include_uppercase = data.get('include_uppercase', True)
    include_lowercase = data.get('include_lowercase', True)
    include_numbers = data.get('include_numbers', True)
    include_symbols = data.get('include_symbols', True)

    password = generate_password(
        length,
        include_uppercase,
        include_lowercase,
        include_numbers,
        include_symbols
    )

    strength = check_password_strength(password)

    return jsonify({
        'password': password,
        'strength': strength
    })

@app.route('/api/passwords/<int:id>', methods=['PATCH'])
@login_required
def update_password(id):
    password = Password.query.get_or_404(id)

    if password.user_id != current_user.id:
        return jsonify({'error': 'Unauthorized'}), 403

    data = request.get_json()

    if 'password' in data:
        # Check new password strength
        strength = check_password_strength(data['password'])
        password.strength_score = strength['score']
        password.encrypted_password = cipher_suite.encrypt(data['password'].encode()).decode()

    if 'title' in data:
        password.title = data['title']
    if 'username' in data:
        password.username = data['username']
    if 'url' in data:
        password.url = data['url']
    if 'notes' in data:
        password.notes = data['notes']
    if 'category' in data:
        password.category = data['category']
    if 'tags' in data:
        password.tags = data['tags']
    if 'expiration_days' in data:
        password.expiration_date = datetime.utcnow() + timedelta(days=int(data['expiration_days']))

    password.last_updated = datetime.utcnow()
    db.session.commit()

    log_audit(
        current_user.id,
        'update',
        'password',
        password.id,
        f"Updated password for {password.title}"
    )

    return jsonify({
        'id': password.id,
        'title': password.title,
        'username': password.username,
        'password': cipher_suite.decrypt(password.encrypted_password.encode()).decode(),
        'url': password.url,
        'notes': password.notes,
        'category': password.category,
        'tags': password.tags,
        'expiration_date': password.expiration_date.isoformat(),
        'strength_score': password.strength_score,
        'last_updated': password.last_updated.isoformat()
    })

@app.route('/api/passwords/<int:id>', methods=['DELETE'])
@login_required
def delete_password(id):
    password = Password.query.get_or_404(id)

    if password.user_id != current_user.id:
        return jsonify({'error': 'Unauthorized'}), 403

    log_audit(
        current_user.id,
        'delete',
        'password',
        password.id,
        f"Deleted password for {password.title}"
    )

    db.session.delete(password)
    db.session.commit()

    return '', 204