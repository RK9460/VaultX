import requests
import json
from datetime import datetime, timedelta

BASE_URL = 'http://localhost:5000/api'

def test_registration():
    """Test user registration with various scenarios"""
    # Test valid registration
    data = {
        'username': 'testuser',
        'password': 'Test123!@#',
        'email': 'test@example.com',
        'phone': '1234567890'
    }
    response = requests.post(f'{BASE_URL}/register', json=data)
    print('Registration response:', response.json())
    assert response.status_code == 201

    # Test invalid email
    data['email'] = 'invalid-email'
    response = requests.post(f'{BASE_URL}/register', json=data)
    assert response.status_code == 400
    print('Invalid email response:', response.json())

    # Test weak password
    data['email'] = 'test2@example.com'
    data['password'] = '123456'
    response = requests.post(f'{BASE_URL}/register', json=data)
    assert response.status_code == 400
    print('Weak password response:', response.json())

    return response.json()

def test_login():
    """Test login functionality"""
    data = {
        'username': 'testuser',
        'password': 'Test123!@#'
    }
    response = requests.post(f'{BASE_URL}/login', json=data)
    print('Login response:', response.json())
    assert response.status_code == 200
    return response.cookies

def test_security_features(cookies):
    """Test security-related features"""
    # Set security questions
    questions = {
        'questions': [
            {'question': 'What is your mother\'s maiden name?', 'answer': 'Smith'},
            {'question': 'What was your first pet\'s name?', 'answer': 'Rover'}
        ]
    }
    response = requests.post(f'{BASE_URL}/security/questions', 
                           json=questions, 
                           cookies=cookies)
    print('Set security questions response:', response.json())

    # Test invalid login attempts
    for _ in range(6):
        response = requests.post(f'{BASE_URL}/login', json={
            'username': 'testuser',
            'password': 'wrongpassword'
        })
        print(f'Invalid login attempt response: {response.status_code}')

    # Try to log in after account is locked
    response = requests.post(f'{BASE_URL}/login', json={
        'username': 'testuser',
        'password': 'Test123!@#'
    })
    print('Login attempt after lock:', response.json())

def test_password_sharing(cookies):
    """Test password sharing functionality"""
    # Create second user for sharing
    data = {
        'username': 'shareuser',
        'password': 'Share123!@#',
        'email': 'share@example.com',
        'phone': '9876543210'
    }
    requests.post(f'{BASE_URL}/register', json=data)

    # Create a password to share
    password_data = {
        'title': 'Shared Password',
        'username': 'sharedaccount',
        'password': 'SharedPass123!',
        'url': 'https://example.com',
        'category': 'Shared'
    }
    response = requests.post(f'{BASE_URL}/passwords', 
                           json=password_data, 
                           cookies=cookies)
    password_id = response.json()['id']

    # Share the password
    share_data = {
        'password_id': password_id,
        'username': 'shareuser',
        'days': 7,
        'can_edit': True
    }
    response = requests.post(f'{BASE_URL}/passwords/share', 
                           json=share_data, 
                           cookies=cookies)
    print('Share password response:', response.json())

    # Get shared passwords
    response = requests.get(f'{BASE_URL}/passwords/shared', cookies=cookies)
    print('Shared passwords response:', response.json())

def test_password_import_export(cookies):
    """Test password import/export functionality"""
    # Export passwords
    response = requests.get(f'{BASE_URL}/passwords/export', cookies=cookies)
    exported_data = response.json()
    print('Export response:', exported_data)

    # Import passwords
    import_data = [{
        'title': 'Imported Password',
        'username': 'importuser',
        'password': 'Import123!',
        'url': 'https://imported.com',
        'category': 'Imported'
    }]
    files = {'file': ('passwords.json', json.dumps(import_data))}
    response = requests.post(f'{BASE_URL}/passwords/import', 
                           files=files, 
                           cookies=cookies)
    print('Import response:', response.json())

def test_password_operations(cookies):
    """Test various password operations"""
    # Test password generation
    gen_response = requests.post(f'{BASE_URL}/passwords/generate', json={
        'length': 16,
        'include_symbols': True
    })
    generated_password = gen_response.json()['password']
    print('Generated password:', generated_password)

    # Create password with categories and tags
    password_data = {
        'title': 'Test Account',
        'username': 'testaccount',
        'password': generated_password,
        'url': 'https://example.com',
        'category': 'Work',
        'tags': 'important,secure',
        'expiration_days': 90
    }
    response = requests.post(f'{BASE_URL}/passwords', 
                           json=password_data, 
                           cookies=cookies)
    print('Create password response:', response.json())
    password_id = response.json()['id']

    # Get all passwords
    response = requests.get(f'{BASE_URL}/passwords', cookies=cookies)
    print('Get passwords response:', response.json())

    # Get password categories
    response = requests.get(f'{BASE_URL}/passwords/categories', cookies=cookies)
    print('Categories response:', response.json())

    # Get expired passwords
    response = requests.get(f'{BASE_URL}/passwords/expired', cookies=cookies)
    print('Expired passwords response:', response.json())


def test_password_recovery():
    """Test master password recovery flow"""
    # First create a user with security questions
    register_data = {
        'username': 'recovery_test',
        'password': 'Initial123!@#',
        'email': 'recovery@test.com',
        'phone': '1234567890'
    }
    response = requests.post(f'{BASE_URL}/register', json=register_data)
    cookies = response.cookies

    # Setup recovery options
    setup_data = {
        'backup_email': 'backup@test.com',
        'questions': [
            {
                'question': 'What was your first pet\'s name?',
                'answer': 'Fluffy'
            },
            {
                'question': 'What city were you born in?',
                'answer': 'London'
            }
        ]
    }
    response = requests.post(f'{BASE_URL}/security/setup', 
                           json=setup_data,
                           cookies=cookies)
    print('Setup recovery response:', response.json())

    # Initiate recovery process
    init_response = requests.post(f'{BASE_URL}/security/init-recovery', 
                                json={'email': 'recovery@test.com'})
    recovery_data = init_response.json()
    print('Init recovery response:', recovery_data)

    # Verify security questions
    verify_data = {
        'token': recovery_data['token'],
        'answers': [
            {
                'question_id': q['id'],
                'answer': 'Fluffy' if q['question'].startswith('What was') else 'London'
            }
            for q in recovery_data['questions']
        ]
    }
    response = requests.post(f'{BASE_URL}/security/verify-answers', 
                           json=verify_data)
    print('Verify answers response:', response.json())

    # Reset master password
    reset_data = {
        'token': recovery_data['token'],
        'new_password': 'NewSecure456!@#'
    }
    response = requests.post(f'{BASE_URL}/security/reset-master-password', 
                           json=reset_data)
    print('Reset master password response:', response.json())

    # Try logging in with new password
    login_data = {
        'username': 'recovery_test',
        'password': 'NewSecure456!@#'
    }
    response = requests.post(f'{BASE_URL}/login', json=login_data)
    print('Login with new password response:', response.json())

if __name__ == '__main__':
    print("\n=== Testing Registration ===")
    user_data = test_registration()

    print("\n=== Testing Login ===")
    cookies = test_login()

    print("\n=== Testing Security Features ===")
    test_security_features(cookies)

    print("\n=== Testing Password Operations ===")
    test_password_operations(cookies)

    print("\n=== Testing Password Sharing ===")
    test_password_sharing(cookies)

    print("\n=== Testing Password Import/Export ===")
    test_password_import_export(cookies)

    print("\n=== Testing Password Recovery ===")
    test_password_recovery()