import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertPasswordSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Password vault routes
  app.get("/api/passwords", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const passwords = await storage.getPasswords(req.user!.id);
    res.json(passwords);
  });

  app.post("/api/passwords", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const validated = insertPasswordSchema.safeParse(req.body);
    if (!validated.success) {
      return res.status(400).json(validated.error);
    }

    const password = await storage.createPassword({
      ...validated.data,
      userId: req.user!.id
    });
    res.status(201).json(password);
  });

  app.patch("/api/passwords/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const validated = insertPasswordSchema.partial().safeParse(req.body);
    if (!validated.success) {
      return res.status(400).json(validated.error);
    }

    const password = await storage.getPassword(parseInt(req.params.id));
    if (!password || password.userId !== req.user!.id) {
      return res.sendStatus(404);
    }

    const updated = await storage.updatePassword(password.id, validated.data);
    res.json(updated);
  });

  app.delete("/api/passwords/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const password = await storage.getPassword(parseInt(req.params.id));
    if (!password || password.userId !== req.user!.id) {
      return res.sendStatus(404);
    }

    await storage.deletePassword(password.id);
    res.sendStatus(204);
  });

  const httpServer = createServer(app);
  return httpServer;
}
