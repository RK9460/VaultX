"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Shield, Search, Plus, Copy, Settings, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface PasswordEntry {
  service: string
  username: string
  category: string
}

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("passwords")
  const [searchQuery, setSearchQuery] = useState("")

  const passwords: PasswordEntry[] = [
    { service: "Gmail Account", username: "user@gmail.com", category: "Personal" },
    { service: "GitHub", username: "developer123", category: "Work" },
    { service: "Netflix", username: "entertainment@email.com", category: "Entertainment" },
  ]

  return (
    <div className="min-h-screen w-full p-4 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 relative overflow-hidden">
      {/* Animated background patterns */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#8BA66333_1px,transparent_1px),linear-gradient(to_bottom,#8BA66333_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_110%)]" />
      </div>

      {/* Header */}
      <motion.div
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="flex items-center justify-between mb-8"
      >
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-primary/10 backdrop-blur-sm">
            <Shield className="w-6 h-6 text-primary" />
          </div>
          <h1 className="text-2xl font-bold bg-gradient-to-r from-white to-white/70 bg-clip-text text-transparent">
            SecureVault
          </h1>
        </div>
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            className="w-10 h-10 rounded-xl bg-white/5 hover:bg-white/10 text-white/70"
          >
            <Settings className="w-5 h-5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="w-10 h-10 rounded-xl bg-white/5 hover:bg-white/10 text-white/70"
          >
            <LogOut className="w-5 h-5" />
          </Button>
        </div>
      </motion.div>

      {/* Tabs and Search */}
      <div className="max-w-5xl mx-auto space-y-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full max-w-md grid-cols-2 mb-8">
            <TabsTrigger value="passwords" className="data-[state=active]:bg-primary/20">
              Passwords
            </TabsTrigger>
            <TabsTrigger value="generator" className="data-[state=active]:bg-primary/20">
              Generator
            </TabsTrigger>
          </TabsList>
        </Tabs>

        <div className="flex items-center gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
            <Input
              placeholder="Search passwords..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-12 pl-12 bg-white/5 border-white/10 text-white rounded-xl focus:bg-white/10 transition-all duration-300"
            />
          </div>
          <Button className="h-12 px-6 bg-primary/80 hover:bg-primary text-white rounded-xl flex items-center gap-2">
            <Plus className="w-4 h-4" />
            Add Password
          </Button>
        </div>

        {/* Password Cards */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="grid gap-4 md:grid-cols-2">
          {passwords.map((entry, index) => (
            <motion.div
              key={entry.service}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="group relative bg-white/5 backdrop-blur-sm rounded-2xl p-6 hover:bg-white/10 transition-all duration-300"
            >
              {/* Glassmorphism effect */}
              <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-2xl" />

              <div className="relative flex items-start justify-between">
                <div className="space-y-1">
                  <h3 className="text-lg font-semibold text-white">{entry.service}</h3>
                  <p className="text-white/50">{entry.username}</p>
                  <span className="inline-block px-3 py-1 text-xs font-medium text-primary bg-primary/10 rounded-full">
                    {entry.category}
                  </span>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/10 text-white/50 hover:text-white"
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </div>
  )
}

