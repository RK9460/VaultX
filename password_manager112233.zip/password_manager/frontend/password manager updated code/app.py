from flask import Flask, jsonify, request
from flask_cors import CORS
import jwt
import datetime

app = Flask(__name__)
CORS(app)

# This should be a secure, randomly generated key in a real application
app.config['SECRET_KEY'] = 'your-secret-key'

# In-memory database for demonstration purposes
users = {
    'user@example.com': {'password': 'password123'}
}

passwords = [
    {'id': 1, 'service': 'Gmail Account', 'username': 'user@gmail.com', 'category': 'Personal'},
    {'id': 2, 'service': 'GitHub', 'username': 'developer123', 'category': 'Work'},
    {'id': 3, 'service': 'Netflix', 'username': 'entertainment@email.com', 'category': 'Entertainment'}
]

def token_required(f):
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization')
        if not token:
            return jsonify({'message': 'Token is missing!'}), 401
        try:
            data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=["HS256"])
        except:
            return jsonify({'message': 'Token is invalid!'}), 401
        return f(*args, **kwargs)
    return decorated

@app.route('/login', methods=['POST'])
def login():
    auth = request.authorization
    if not auth or not auth.username or not auth.password:
        return jsonify({'message': 'Could not verify'}), 401
    
    if auth.username in users and users[auth.username]['password'] == auth.password:
        token = jwt.encode({'user': auth.username, 'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=24)},
                           app.config['SECRET_KEY'], algorithm="HS256")
        return jsonify({'token': token})
    
    return jsonify({'message': 'Could not verify'}), 401

@app.route('/passwords', methods=['GET'])
@token_required
def get_passwords():
    return jsonify(passwords)

@app.route('/password', methods=['POST'])
@token_required
def add_password():
    new_password = {
        'id': len(passwords) + 1,
        'service': request.json['service'],
        'username': request.json['username'],
        'category': request.json['category']
    }
    passwords.append(new_password)
    return jsonify(new_password), 201

@app.route('/password/<int:password_id>', methods=['PUT'])
@token_required
def update_password(password_id):
    password = next((p for p in passwords if p['id'] == password_id), None)
    if password:
        password.update(request.json)
        return jsonify(password)
    return jsonify({'message': 'Password not found'}), 404

@app.route('/password/<int:password_id>', methods=['DELETE'])
@token_required
def delete_password(password_id):
    global passwords
    passwords = [p for p in passwords if p['id'] != password_id]
    return jsonify({'message': 'Password deleted'})

if __name__ == '__main__':
    app.run(debug=True)

